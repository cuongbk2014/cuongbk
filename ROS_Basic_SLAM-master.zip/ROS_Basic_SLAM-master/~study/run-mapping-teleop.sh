#!/bin/bash

source devel/setup.bash

roslaunch robot_navigation mybot_teleop.launch
