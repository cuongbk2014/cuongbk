#!/bin/bash

source devel/setup.bash

roslaunch robot_description mybot_rviz_amcl.launch
