#!/bin/bash

source devel/setup.bash

rosrun map_server map_saver -f ~/dev/robot_ws/src/robot_navigation/map/test_map
