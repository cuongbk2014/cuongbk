#!/bin/bash

source devel/setup.bash

roslaunch robot_navigation gmapping_demo.launch
