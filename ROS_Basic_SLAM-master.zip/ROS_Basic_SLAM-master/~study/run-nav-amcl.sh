#!/bin/bash

source devel/setup.bash

roslaunch robot_navigation amcl_demo.launch
